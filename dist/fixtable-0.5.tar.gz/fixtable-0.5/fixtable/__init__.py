import fixtable
